BiocGenerics:::testPackage("BrowserVizTemplate")
